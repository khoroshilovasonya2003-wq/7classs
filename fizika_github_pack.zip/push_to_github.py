#!/usr/bin/env python3
"""
Загрузка файлов физики на GitHub + включение GitHub Pages
Запусти: python3 push_to_github.py
"""
import urllib.request, urllib.error, json, base64, os, sys

TOKEN  = "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"
# ─── ЗАПОЛНИ ЭТИ ДВА ПОЛЯ ───────────────────────────────────────
USERNAME = ""          # например: hoshilova-sonya
REPO     = ""          # например: fizika-7klass  (будет создан если нет)
# ────────────────────────────────────────────────────────────────

FILES = [
    ("index.html",                  "index.html"),
    ("vitalki_sila_urok.html",      "vitalki_sila_urok.html"),
    ("lab_arximed.html",            "lab_arximed.html"),
    ("fizicheskiy_slovar_test.html","fizicheskiy_slovar_test.html"),
]

HEADERS = {
    "Authorization": f"token {TOKEN}",
    "Accept":        "application/vnd.github+json",
    "Content-Type":  "application/json",
    "User-Agent":    "fizika-uploader/1.0",
}

def gh(method, path, data=None):
    url  = f"https://api.github.com{path}"
    body = json.dumps(data).encode() if data else None
    req  = urllib.request.Request(url, data=body, headers=HEADERS, method=method)
    try:
        with urllib.request.urlopen(req) as r:
            return json.loads(r.read()), r.status
    except urllib.error.HTTPError as e:
        return json.loads(e.read()), e.code

def main():
    if not USERNAME or not REPO:
        print("❌  Заполни USERNAME и REPO в скрипте!")
        sys.exit(1)

    # 1. Создать репозиторий если не существует
    print(f"🔍  Проверяю репозиторий {USERNAME}/{REPO}...")
    _, status = gh("GET", f"/repos/{USERNAME}/{REPO}")
    if status == 404:
        print(f"📦  Создаю репозиторий {REPO}...")
        _, s = gh("POST", "/user/repos", {
            "name": REPO, "description": "Физика 7 класс — Пёрышкин",
            "private": False, "auto_init": True
        })
        if s not in (200, 201):
            print(f"❌  Ошибка создания репозитория (статус {s})")
            sys.exit(1)
        print(f"✅  Репозиторий создан!")
    else:
        print(f"✅  Репозиторий найден!")

    # 2. Загрузить файлы
    script_dir = os.path.dirname(os.path.abspath(__file__))
    for local_name, remote_name in FILES:
        path = os.path.join(script_dir, local_name)
        if not os.path.exists(path):
            print(f"⚠️   Файл не найден: {path}")
            continue

        with open(path, "rb") as f:
            content_b64 = base64.b64encode(f.read()).decode()

        # Получить SHA если файл уже есть
        existing, _ = gh("GET", f"/repos/{USERNAME}/{REPO}/contents/{remote_name}")
        sha = existing.get("sha") if isinstance(existing, dict) else None

        payload = {
            "message": f"Добавить {remote_name}",
            "content": content_b64,
        }
        if sha:
            payload["sha"] = sha
            payload["message"] = f"Обновить {remote_name}"

        _, s = gh("PUT", f"/repos/{USERNAME}/{REPO}/contents/{remote_name}", payload)
        if s in (200, 201):
            print(f"✅  {remote_name}")
        else:
            print(f"❌  Ошибка загрузки {remote_name} (статус {s})")

    # 3. Включить GitHub Pages (ветка main, папка root)
    print("\n🌐  Включаю GitHub Pages...")
    _, s = gh("POST", f"/repos/{USERNAME}/{REPO}/pages", {
        "source": {"branch": "main", "path": "/"}
    })
    if s in (200, 201):
        print(f"✅  GitHub Pages включены!")
    elif s == 409:
        print(f"✅  GitHub Pages уже включены")
    else:
        print(f"⚠️   Pages: статус {s} (включи вручную в Settings → Pages)")

    print(f"\n🎉  Готово!")
    print(f"🔗  Репозиторий: https://github.com/{USERNAME}/{REPO}")
    print(f"🌍  Сайт (через 1-2 мин): https://{USERNAME}.github.io/{REPO}/")

if __name__ == "__main__":
    main()
